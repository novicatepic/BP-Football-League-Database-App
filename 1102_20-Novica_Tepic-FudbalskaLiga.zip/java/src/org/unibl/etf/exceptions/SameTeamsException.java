package org.unibl.etf.exceptions;

public class SameTeamsException extends Exception {

	public SameTeamsException() {}
	
	public SameTeamsException(String mssg) {
		super(mssg);
	}
	
}
