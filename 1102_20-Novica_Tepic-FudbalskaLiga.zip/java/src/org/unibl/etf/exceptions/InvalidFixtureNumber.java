package org.unibl.etf.exceptions;

public class InvalidFixtureNumber extends Exception {

	public InvalidFixtureNumber() {}
	
	public InvalidFixtureNumber(String mssg) {
		super(mssg);
	}
	
}
